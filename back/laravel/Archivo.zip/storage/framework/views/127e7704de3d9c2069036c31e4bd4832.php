<?php $__env->startSection('dashboard'); ?>
entradas
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/dashboard/entradas.blade.php ENDPATH**/ ?>