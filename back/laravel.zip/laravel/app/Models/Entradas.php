<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Entradas extends Model
{
    protected $fillable = [
        'user_email',
        'showtime_id',
        'fila',
        'columna',
        'vip',
        'precio'
    ];

    public function showtime()
    {
        return $this->belongsTo(Showtime::class);
    }
}
